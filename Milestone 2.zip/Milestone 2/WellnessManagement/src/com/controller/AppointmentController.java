package com.controller;

import com.dao.AppointmentDAOImpl;
import com.model.Appointment;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import static com.dao.DBConnection.getConnection;

public class AppointmentController {

    private AppointmentDAOImpl appointmentDAOImpl;

    public AppointmentController() {
        try {
            Connection conn = getConnection();
            this.appointmentDAOImpl = new AppointmentDAOImpl(conn);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed to connect to the database.");
            e.printStackTrace();
        }
    }

    public boolean bookAppointment(Appointment a) {
        if (appointmentDAOImpl.hasConflict(a.getCounselor(), a.getDate(), a.getTime())) {
            JOptionPane.showMessageDialog(null, "This time slot is already booked for the counselor.");
            return false;
        }
        appointmentDAOImpl.registerAppointment(a);
        return true;
    }

    public boolean cancelAppointment(int id) {
        appointmentDAOImpl.deleteAppointment(id);
        return true;
    }

    public List<Appointment> getAppointmentsByStudent(String studentName) {
        return appointmentDAOImpl.getAppointmentsByStudent(studentName);
    }

    public List<Appointment> getAllAppointments() {
        return appointmentDAOImpl.getAppointments();
    }
}
